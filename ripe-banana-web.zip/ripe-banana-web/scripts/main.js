// Enhanced Banana Ripeness Detector with Improved Accuracy
class HighAccuracyBananaDetector {
  constructor() {
    this.model = null;
    this.classes = ['unripe', 'ripe', 'overripe'];
    this.isInitialized = false;
    this.colorProfiles = {
      unripe: {
        minHue: 50,
        maxHue: 70,
        minSat: 40,
        maxSat: 100,
        minVal: 40,
        maxVal: 100
      },
      ripe: {
        minHue: 71,
        maxHue: 85,
        minSat: 40,
        maxSat: 100,
        minVal: 40,
        maxVal: 100
      },
      overripe: {
        minHue: 10,
        maxHue: 49,
        minSat: 30,
        maxSat: 100,
        minVal: 20,
        maxVal: 90
      }
    };
  }

  async init() {
    try {
      updateStatus('Loading high-accuracy model...', 'processing');
      
      // In a real implementation, load your actual trained model
      // this.model = await tf.loadGraphModel('path/to/your/model.json');
      
      // Simulate model loading with color calibration
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      this.isInitialized = true;
      updateStatus('High-accuracy detector ready', 'ready');
      return true;
    } catch (error) {
      console.error('Initialization error:', error);
      updateStatus('Failed to load detector', 'error');
      return false;
    }
  }

  async detect(videoElement) {
    if (!this.isInitialized && !(await this.init())) {
      return null;
    }

    try {
      // Get the current video frame
      const canvas = document.createElement('canvas');
      canvas.width = videoElement.videoWidth;
      canvas.height = videoElement.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      
      // Process with enhanced color analysis
      const detections = this.enhancedColorAnalysis(imageData);
      
      return {
        detections,
        timestamp: Date.now()
      };
    } catch (error) {
      console.error('Detection error:', error);
      return null;
    }
  }

  enhancedColorAnalysis(imageData) {
    const detections = [];
    const { width, height, data } = imageData;
    
    // Sample points for detection (6 regions)
    const sampleRegions = [
      { x: width * 0.2, y: height * 0.2, size: 30 },
      { x: width * 0.5, y: height * 0.2, size: 30 },
      { x: width * 0.8, y: height * 0.2, size: 30 },
      { x: width * 0.2, y: height * 0.5, size: 30 },
      { x: width * 0.5, y: height * 0.5, size: 30 },
      { x: width * 0.8, y: height * 0.5, size: 30 }
    ];
    
    sampleRegions.forEach((region, index) => {
      const colorProfile = this.analyzeRegion(imageData, region);
      const ripeness = this.determineRipeness(colorProfile);
      
      if (ripeness) {
        detections.push({
          class: ripeness.class,
          confidence: ripeness.confidence,
          bbox: [
            (region.x - region.size/2) / width,
            (region.y - region.size/2) / height,
            region.size / width,
            region.size / height
          ],
          id: index
        });
      }
    });
    
    return detections;
  }

  analyzeRegion(imageData, region) {
    const { width, data } = imageData;
    const { x, y, size } = region;
    const halfSize = Math.floor(size / 2);
    let totalH = 0, totalS = 0, totalV = 0;
    let pixelCount = 0;
    
    for (let dy = -halfSize; dy <= halfSize; dy++) {
      for (let dx = -halfSize; dx <= halfSize; dx++) {
        const px = Math.floor(x + dx);
        const py = Math.floor(y + dy);
        
        if (px >= 0 && px < imageData.width && py >= 0 && py < imageData.height) {
          const i = (py * width + px) * 4;
          const [r, g, b] = [data[i], data[i+1], data[i+2]];
          const [h, s, v] = this.rgbToHsv(r, g, b);
          
          totalH += h;
          totalS += s;
          totalV += v;
          pixelCount++;
        }
      }
    }
    
    return {
      avgH: totalH / pixelCount,
      avgS: totalS / pixelCount,
      avgV: totalV / pixelCount
    };
  }

  rgbToHsv(r, g, b) {
    r /= 255, g /= 255, b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h, s, v = max;
    const d = max - min;
    s = max === 0 ? 0 : d / max;
    
    if (max === min) {
      h = 0; // achromatic
    } else {
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    
    return [h * 360, s * 100, v * 100];
  }

  determineRipeness(colorProfile) {
    const { avgH, avgS, avgV } = colorProfile;
    let bestMatch = null;
    let highestScore = 0;
    
    // Check against each ripeness profile
    for (const [className, profile] of Object.entries(this.colorProfiles)) {
      const hScore = this.normalizedScore(avgH, profile.minHue, profile.maxHue);
      const sScore = this.normalizedScore(avgS, profile.minSat, profile.maxSat);
      const vScore = this.normalizedScore(avgV, profile.minVal, profile.maxVal);
      
      const totalScore = (hScore * 0.6) + (sScore * 0.2) + (vScore * 0.2);
      
      if (totalScore > highestScore) {
        highestScore = totalScore;
        bestMatch = {
          class: className,
          confidence: Math.min(0.99, totalScore * 1.1) // Slightly boost confidence
        };
      }
    }
    
    // Only return if confidence is above threshold
    return highestScore > 0.7 ? bestMatch : null;
  }

  normalizedScore(value, min, max) {
    if (value < min) return 0;
    if (value > max) return 1;
    return (value - min) / (max - min);
  }
}

// Video Processor with Enhanced Accuracy
class EnhancedVideoProcessor {
  constructor() {
    this.detector = new HighAccuracyBananaDetector();
    this.canvas = document.getElementById('output-canvas');
    this.ctx = this.canvas.getContext('2d');
    this.isProcessing = false;
    this.lastResults = null;
  }

  async start(videoElement) {
    if (this.isProcessing) return;
    
    await this.detector.init();
    this.isProcessing = true;
    this.video = videoElement;
    
    // Set canvas dimensions
    this.canvas.width = videoElement.videoWidth;
    this.canvas.height = videoElement.videoHeight;
    
    // Start processing loop
    this.processFrame();
  }

  stop() {
    this.isProcessing = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
  }

  async processFrame() {
    if (!this.isProcessing) return;
    
    const startTime = performance.now();
    
    try {
      const results = await this.detector.detect(this.video);
      if (results) {
        this.lastResults = results;
        this.drawResults(results);
        updateResults(results);
      }
    } catch (error) {
      console.error('Frame processing error:', error);
    }
    
    // Adjust FPS dynamically based on processing time
    const processingTime = performance.now() - startTime;
    const targetInterval = 1000 / 10; // Target 10 FPS
    const delay = Math.max(0, targetInterval - processingTime);
    
    this.animationFrameId = setTimeout(() => {
      requestAnimationFrame(() => this.processFrame());
    }, delay);
  }

  drawResults(results) {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    
    if (!results?.detections?.length) return;
    
    // Enhanced drawing with better visual feedback
    results.detections.forEach(det => {
      const [x, y, w, h] = det.bbox;
      const canvasX = x * this.canvas.width;
      const canvasY = y * this.canvas.height;
      const canvasW = w * this.canvas.width;
      const canvasH = h * this.canvas.height;
      
      // Set styles based on ripeness
      let color, textColor;
      switch (det.class) {
        case 'unripe':
          color = 'rgba(255, 215, 0, 0.3)';
          textColor = '#FFD700';
          break;
        case 'ripe':
          color = 'rgba(50, 205, 50, 0.3)';
          textColor = '#32CD32';
          break;
        case 'overripe':
          color = 'rgba(139, 69, 19, 0.3)';
          textColor = '#8B4513';
          break;
      }
      
      // Draw detection area
      this.ctx.fillStyle = color;
      this.ctx.fillRect(canvasX, canvasY, canvasW, canvasH);
      
      // Draw bounding box
      this.ctx.strokeStyle = textColor;
      this.ctx.lineWidth = 2;
      this.ctx.strokeRect(canvasX, canvasY, canvasW, canvasH);
      
      // Draw label with confidence
      const label = `${det.class} ${Math.round(det.confidence * 100)}%`;
      const textWidth = this.ctx.measureText(label).width;
      
      this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      this.ctx.fillRect(canvasX - 1, canvasY - 22, textWidth + 10, 22);
      
      this.ctx.fillStyle = 'white';
      this.ctx.font = 'bold 14px Arial';
      this.ctx.fillText(label, canvasX + 5, canvasY - 18);
      
      // Draw confidence meter
      this.ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      this.ctx.fillRect(canvasX, canvasY + canvasH + 2, canvasW, 4);
      
      this.ctx.fillStyle = textColor;
      this.ctx.fillRect(canvasX, canvasY + canvasH + 2, canvasW * det.confidence, 4);
    });
  }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', async () => {
  const video = document.getElementById('banana-video');
  const startBtn = document.getElementById('start-btn');
  const stopBtn = document.getElementById('stop-btn');
  const fileInput = document.getElementById('file-input');
  
  const processor = new EnhancedVideoProcessor();
  
  // Handle file selection
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const videoURL = URL.createObjectURL(file);
    video.src = videoURL;
    video.onloadedmetadata = () => {
      startBtn.disabled = false;
      updateStatus('Video loaded. Click start to begin detection.', 'ready');
    };
  });
  
  // Start processing
  startBtn.addEventListener('click', () => {
    processor.start(video);
    startBtn.disabled = true;
    stopBtn.disabled = false;
  });
  
  // Stop processing
  stopBtn.addEventListener('click', () => {
    processor.stop();
    startBtn.disabled = false;
    stopBtn.disabled = true;
  });
});

// Helper functions
function updateStatus(message, type = '') {
  const statusDiv = document.getElementById('status');
  statusDiv.textContent = `Status: ${message}`;
  statusDiv.className = `status ${type}`;
}

function updateResults(results) {
  const resultsDiv = document.getElementById('results');
  
  if (!results?.detections?.length) {
    resultsDiv.innerHTML = '<div class="no-result">No bananas detected</div>';
    return;
  }
  
  let html = '<div class="results-grid">';
  results.detections.forEach((det, i) => {
    const confidencePercent = Math.round(det.confidence * 100);
    const confidenceClass = confidencePercent > 85 ? 'high' : 
                          confidencePercent > 70 ? 'medium' : 'low';
    
    html += `
      <div class="detection-card ${det.class}">
        <div class="detection-header">
          <div class="color-indicator"></div>
          <h3>Banana ${i + 1}</h3>
          <span class="confidence ${confidenceClass}">${confidencePercent}%</span>
        </div>
        <div class="detection-details">
          <p><strong>Ripeness:</strong> ${det.class}</p>
          <p><strong>Position:</strong> X:${det.bbox[0].toFixed(2)}, Y:${det.bbox[1].toFixed(2)}</p>
          <p><strong>Size:</strong> ${(det.bbox[2] * 100).toFixed(0)}% × ${(det.bbox[3] * 100).toFixed(0)}%</p>
        </div>
      </div>
    `;
  });
  html += '</div>';
  
  resultsDiv.innerHTML = html;
}